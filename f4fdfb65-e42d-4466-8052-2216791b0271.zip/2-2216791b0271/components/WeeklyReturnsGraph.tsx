
// This component has been removed as per user request
// The graph functionality has been reverted from the season stats page

import React from 'react';
import { View, Text } from 'react-native';

interface WeeklyReturnsGraphProps {
  weeklyData: any[];
  currentWeek: number;
}

export default function WeeklyReturnsGraph({ weeklyData, currentWeek }: WeeklyReturnsGraphProps) {
  // Component removed - no longer used
  return null;
}
